function showCalendar(fieldId,altFieldId,disableDate,minDateFieldId,maxDateFieldId,minNoOfDays,maxNoOfDays)
{
	var format = 'yy-mm-dd', altDateFormat = 'yy-mm-dd';
	$( "#"+fieldId).datepicker
	({
		showOn				: 'none',
		showOtherMonths		: true,
		selectOtherMonths	: true,
		changeMonth			: true,
		changeYear			: true,
		dateFormat			: format,
		showWeek			: true,
		firstDay			: 1,
		yearRange			: 'c-50:c+50'
	});

    if($('#ui-datepicker-div').hasClass("groupRMDatePicker") == false)
        $('#ui-datepicker-div').addClass("groupRMDatePicker");

	if(disableDate)
	{
		$( "#"+fieldId ).datepicker( "option", disableDate+"Date" , new Date());
	}
	if(minDateFieldId)
	{
		var minValidityDate = null;
		if(document.getElementById( minDateFieldId ))
		{
			minValidityDate = $( "#"+minDateFieldId ).datepicker( "getDate" );
			if(minValidityDate != null)
			{
				minNoOfDays = (minNoOfDays) ? minNoOfDays : 0;
				minValidityDate = minValidityDate.addDays(minNoOfDays);
				$( "#"+fieldId ).datepicker( "option", "minDate" , minValidityDate);
			}
			else if(minValidityDate == null && disableDate == 'max')
			{
							
				$( "#"+fieldId ).datepicker( "option", "minDate" , minValidityDate);
			}
		}
	}
	if(maxDateFieldId)
	{
		var maxValidityDate = null;
		if(document.getElementById( maxDateFieldId ))
		{
			maxValidityDate = $( "#"+maxDateFieldId ).datepicker( "getDate" );
			if(maxValidityDate != null)
			{
				maxNoOfDays = (maxNoOfDays) ? maxNoOfDays : 0;
				maxValidityDate = maxValidityDate.addDays(maxNoOfDays);
				$( "#"+fieldId ).datepicker( "option", "maxDate" , maxValidityDate);
			}			
		}
	}
    if(altFieldId)
    {
        $( "#"+fieldId ).datepicker( "option", {
            altField    : "#"+altFieldId,
            altFormat    : altDateFormat,
            onSelect    : function(dateText, inst)
            {
                $("#"+altFieldId).change();
            }
        } );
    }
    $('#'+fieldId).delay('fast').focus();
    $('#'+fieldId).datepicker('show');
}


function Calendar(fieldId,altFieldId,disableDate,minDateFieldId,maxDateFieldId,minNoOfDays,maxNoOfDays)
{
	var format = 'yy-mm-dd', altDateFormat = 'yy-mm-dd';
	$( "#"+fieldId).datepicker
	({
		showOn				: 'none',
		showOtherMonths		: true,
		selectOtherMonths	: true,
		changeMonth			: true,
		changeYear			: true,
		dateFormat			: format,
		showWeek			: true,
		firstDay			: 1,
		yearRange			: 'c-50:c+50'
	});

    if($('#ui-datepicker-div').hasClass("groupRMDatePicker") == false)
        $('#ui-datepicker-div').addClass("groupRMDatePicker");

	if(disableDate)
	{
		$( "#"+fieldId ).datepicker( "option", disableDate+"Date" , new Date());
	}
	if(minDateFieldId)
	{
		var minValidityDate = null;
		if(document.getElementById( minDateFieldId ))
		{
			minValidityDate = $( "#"+minDateFieldId ).datepicker( "getDate" );
			if(minValidityDate != null)
			{
				minNoOfDays = (minNoOfDays) ? minNoOfDays : 0;
				minValidityDate = minValidityDate.addDays(minNoOfDays);
				$( "#"+fieldId ).datepicker( "option", "minDate" , minValidityDate);
			}
			else if(minValidityDate == null && disableDate == 'max')
			{
							
				$( "#"+fieldId ).datepicker( "option", "minDate" , minValidityDate);
			}
		}
	}
	if(maxDateFieldId)
	{
		var maxValidityDate = null;
		if(document.getElementById( maxDateFieldId ))
		{
			maxValidityDate = $( "#"+maxDateFieldId ).datepicker( "getDate" );
			if(maxValidityDate != null)
			{
				maxNoOfDays = (maxNoOfDays) ? maxNoOfDays : 0;
				maxValidityDate = maxValidityDate.addDays(maxNoOfDays);
				$( "#"+fieldId ).datepicker( "option", "maxDate" , maxValidityDate);
			}			
		}
	}
    if(altFieldId)
    {
        $( "#"+fieldId ).datepicker( "option", {
            altField    : "#"+altFieldId,
            altFormat    : altDateFormat,
            onSelect    : function(dateText, inst)
            {
                $("#"+altFieldId).change();
            }
        } );
    }
    $('#'+fieldId).delay('fast').focus();
    $('#'+fieldId).datepicker('show');
}






