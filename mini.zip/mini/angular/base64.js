/* RC4 symmetric cipher encryption/decryption
 * Copyright (c) 2006 by Ali Farhadi.
 * released under the terms of the Gnu Public License.
 * see the GPL for details.
 *
 * Email: ali[at]farhadi[dot]ir
 * Website: http://farhadi.ir/
 */
/**
 * Encrypt given plain text using the key with RC4 algorithm.
 * All parameters and return value are in binary format.
 *
 * @param string key - secret key for encryption
 * @param string pt - plain text to be encrypted
 * @return string
 */
function rc4Encrypt(key, pt) {
    s = new Array();
    for (var i = 0; i < 256; i++) {
        s[i] = i;
    }
    var j = 0;
    var x;
    for (i = 0; i < 256; i++) {
        j = (j + s[i] + key.charCodeAt(i % key.length)) % 256;
        x = s[i];
        s[i] = s[j];
        s[j] = x;
    }
    i = 0;
    j = 0;
    var ct = '';
    for (var y = 0; y < pt.length; y++) {
        i = (i + 1) % 256;
        j = (j + s[i]) % 256;
        x = s[i];
        s[i] = s[j];
        s[j] = x;
        ct += String.fromCharCode(pt.charCodeAt(y) ^ s[(s[i] + s[j]) % 256]);
    }
    return ct;
}
/**
 * Decrypt given cipher text using the key with RC4 algorithm.
 * All parameters and return value are in binary format.
 *
 * @param string key - secret key for decryption
 * @param string ct - cipher text to be decrypted
 * @return string
 */
function rc4Decrypt(key, ct)
{
    return rc4Encrypt(key, ct);
}

// This code was written by Tyler Akins and has been placed in the
// public domain. It would be nice if you left this header intact.
// Base64 code from Tyler Akins -- http://rumkin.com
var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

function encode64(input)
{
    var output = "";
    var chr1, chr2, chr3;
    var enc1, enc2, enc3, enc4;
    var i = 0;
    do
    {
        chr1 = input.charCodeAt(i++);
        chr2 = input.charCodeAt(i++);
        chr3 = input.charCodeAt(i++);
        enc1 = chr1 >> 2;
        enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
        enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
        enc4 = chr3 & 63;
        if (isNaN(chr2))
        {
            enc3 = enc4 = 64;
        }
        else if (isNaN(chr3))
        {
            enc4 = 64;
        }
        output = output + keyStr.charAt(enc1) + keyStr.charAt(enc2) + keyStr.charAt(enc3) + keyStr.charAt(enc4);
    }
    while (i < input.length);
    return output;
}

function decode64(input)
{
    var output = "";
    var chr1, chr2, chr3;
    var enc1, enc2, enc3, enc4;
    var i = 0;
    // remove all characters that are not A-Z, a-z, 0-9, +, /, or =
    input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
    do
    {
        enc1 = keyStr.indexOf(input.charAt(i++));
        enc2 = keyStr.indexOf(input.charAt(i++));
        enc3 = keyStr.indexOf(input.charAt(i++));
        enc4 = keyStr.indexOf(input.charAt(i++));
        chr1 = (enc1 << 2) | (enc2 >> 4);
        chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
        chr3 = ((enc3 & 3) << 6) | enc4;
        output = output + String.fromCharCode(chr1);
        if (enc3 != 64)
        {
            output = output + String.fromCharCode(chr2);
        }
        if (enc4 != 64)
        {
            output = output + String.fromCharCode(chr3);
        }
    }
    while (i < input.length);
    return output;
}

function decriptValue()
{
    var initialValue = document.getElementById('hiddenVal').value;

    var randomkey = "0.101492156064763tmjnni45idjc3455jdpeqz45";

    document.getElementById('hiddenValRet').value = decode64(rc4Decrypt(randomkey, initialValue));
    var decodeName = decode64(document.getElementById('hiddenValR').value);
    var pos = decodeName.substr(decodeName.length - 1);
    var decodeName1 = decodeName.substr(0, pos);
    var decodeName2 = decodeName.substr(Number(pos) + 4, decodeName.length);
    document.getElementById('hiddenValRet1').value = decode64(document.getElementById('hiddenValR').value);
    document.getElementById('hiddenValRet11').value = decodeName1 + decodeName2;
}

function getRandomizer(bottom, top) {

    var a = Math.floor(Math.random() * (1 + top - bottom)) + bottom;
    if (a > 9)
    {
        a = a % 10;
        if (a == 0)
        {
            a = 1;
        }
    }

    return a;

}

function randomString(len) {
    charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var randomString = '';
    for (var i = 0; i < len; i++) {
        var randomPoz = Math.floor(Math.random() * charSet.length);
        randomString += charSet.substring(randomPoz, randomPoz + 1);
    }
    return randomString;
}

function encriptValue(initialValue)
{
    var randomkey = "0.101492156064763tmjnni45idjc3455jdpeqz45";
    var str = '';
    var randomString1 = randomString(4);
    var positionNumber = getRandomizer(1, initialValue.length - 1);
    for (var i = 0; i < initialValue.length; i++)
    {
        if (i == positionNumber)
        {
            str = str + randomString1;
        }
        str = str + initialValue.charAt(i);
    }
    str = str + positionNumber;
    return encode64(str);
    ;
}

function encryptArray(form)
{

    if (!form)
    {
        var tempForm = [];
        tempForm['encrypt'] = 'Y';
        return multiArrayForm(tempForm);
    }
    if (typeof (form) === 'object')
    {
        form['encrypt'] = 'Y';
        return multiArrayForm($.extend([], form));
    }
    else
    {
        var tempForm = [];
        tempForm['encrypt'] = 'Y';
        tempForm['singleValue'] = form;
        return multiArrayForm(tempForm);
        ;
    }

}
function multiArrayForm(form)
{
    for (var key in form)
    {
        if (typeof (form[key]) === 'object')
        {
            form[key] = multiArrayForm($.extend([], form[key]));
        }
        else
        {
            if (!encryptCheck(key))
                form[key] = encryptKeyValue(form[key]);
        }

    }
    return form;
}

function encryptCheck(key)
{
    var fieldArray = [];
    var i = 9;
    for (var i in fieldArray)
    {
        if (fieldArray[i] == key)
            return true;
    }
    return false;
}

function encryptKeyValue(value)
{
    if (!value)
    {
        return value;
    }
    elementValue = String(value);
    if (elementValue.length == 1)
    {
        return encode64(elementValue);
    }
    var randomkey = "0.101492156064763tmjnni45idjc3455jdpeqz45";
    var str = '';
    var randomString1 = randomString(4);
    var positionNumber = getRandomizer(1, elementValue.length - 1);
    //alert(elementValue.toSource());
    for (var j = 0; j < elementValue.length; j++)
    {
        if (j == positionNumber)
        {
            str = str + randomString1;
        }
        str = str + elementValue.charAt(j);
    }
    str = str + positionNumber;
    return encode64(str);
}
/**
 *
 *  Base64 encode / decode
 *  http://www.webtoolkit.info/
 *
 **/

var Base64 = {
    // private property
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    // public method for encoding
    encode: function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;

        input = Base64._utf8_encode(input);

        while (i < input.length) {

            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);

            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;

            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }

            output = output +
                    this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) +
                    this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);

        }

        return output;
    },
    // public method for decoding
    decode: function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;

        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");

        while (i < input.length) {

            enc1 = this._keyStr.indexOf(input.charAt(i++));
            enc2 = this._keyStr.indexOf(input.charAt(i++));
            enc3 = this._keyStr.indexOf(input.charAt(i++));
            enc4 = this._keyStr.indexOf(input.charAt(i++));

            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;

            output = output + String.fromCharCode(chr1);

            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }

        }

        output = Base64._utf8_decode(output);

        return output;

    },
    // private method for UTF-8 encoding
    _utf8_encode: function (string) {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";

        for (var n = 0; n < string.length; n++) {

            var c = string.charCodeAt(n);

            if (c < 128) {
                utftext += String.fromCharCode(c);
            }
            else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            }
            else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }

        return utftext;
    },
    // private method for UTF-8 decoding
    _utf8_decode: function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;

        while (i < utftext.length) {

            c = utftext.charCodeAt(i);

            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            }
            else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            }
            else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }

        }

        return string;
    }

}