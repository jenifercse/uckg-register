 var app = angular.module('app', []);

app.controller('LoginController',function($scope){

    $scope.checkUserLogin = function(){
        console.log("entered in js")
       
        if ($scope.loginform.username == ""){
            $('#message').empty().append('Please enter valid id');
            return false;
        }
       
        var condition = /^([a-zA-Z0-9_\-\.])+\@([a-zA-Z0-9_\-\.]{2,20})+\.([a-zA-Z]{2,8})$/;
        var emailFlag = false;
        if(condition.test($$scope.loginform.username)){
           emailFlag = true;
        }else{
            emailFlag = false;
        }
        if($scope.loginform.password == ""){
            $('#message').empty().append('Please enter password');
            return false;
        }
               
        var emailValue = $scope.loginform.username;
       if($scope.loginform.username == "balmer"&& $scope.loginform.password == "balmer")
       {
           $scope.view = true;
           $http.post("http://localhost/mini/login.php?action=edit&name="+$scope.username+"&mark="+$scope.password+"&id="+$scope.s_no)
              .then(function(response) {
                  alert(response.data);
                console.log(response.data);
                $scope.getData();
              });
       
       }
        else{
            window.alert("incorrect username or password");
            window.reload();
        }
    };    
    
    
   
})


