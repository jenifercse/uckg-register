<?php
ini_set("display_errors", 1);
$action = $_POST'action'];

if(empty($action)) {
	$action = "post";
}

$servername = "localhost";
$username = "root";
$password = "infiniti";
$dbname = "api";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

switch ($action) {
	case 'get':
		$sql = "SELECT s_no,name,mark FROM students";
		$result = $conn->query($sql);

		$data = array();
		if ($result->num_rows > 0) {
		    // output data of each row
		    while($row = $result->fetch_assoc()) {
		        $data[] = $row;
		    }
		}
		$conn->close();
		print_r(json_encode($data));
		break;
	case 'add':
		$sql = "INSERT INTO vyg values('','".$_GET['username']."','".$_GET['password']."')";
		$result = $conn->query($sql);
		$conn->close();
		echo "Successfully added";
		break;
	case 'edit':
		$sql = "UPDATE students set name='".$_GET['name']."',mark='".$_GET['mark']."' WHERE s_no=".$_GET['id'];
		$result = $conn->query($sql);
		$conn->close();
		echo "Successfully updated";
		break;
	case 'delete':
		$sql = "DELETE FROM students WHERE s_no=".$_GET['id'];
		$result = $conn->query($sql);
		$conn->close();
		echo "Successfully deleted";
		break;
	default:
		# code...
		break;
}


?>